
import 'vision.dart';

class GoogleMlKit {
GoogleMlKit._();

static final Vision vision = Vision.instance;
}