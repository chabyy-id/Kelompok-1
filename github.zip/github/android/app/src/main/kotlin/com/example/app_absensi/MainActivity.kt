package com.example.app_absensi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
